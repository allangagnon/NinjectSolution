﻿namespace SamuraiNinject
{
    interface IWarrior
    {
        void Attack(string target);
    }
}