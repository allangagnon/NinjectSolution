﻿namespace SamuraiNinject
{
    internal interface IWeapon
    {
        void Hit(string target);
    }
}