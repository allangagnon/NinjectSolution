﻿namespace Shogun
{
    internal interface IWeapon
    {
        void Hit(string target);
    }
}