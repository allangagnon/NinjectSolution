﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shogun
{
    class Program
    {
        static void Main()
        {
            Samurai warrior1 = new Samurai(new Shuriken());
            Samurai warrior2 = new Samurai(new Sword());
            warrior1.Attack("the evildoers");
            warrior2.Attack("the evildoers");
        }
    }
}
