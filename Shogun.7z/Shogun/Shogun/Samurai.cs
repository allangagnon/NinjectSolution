﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shogun
{
    class Samurai
    {
        private IWeapon _weapon;
        public Samurai(IWeapon weapon)
        {
            _weapon = weapon;
        }
        public void Attack(string target)
        {
            _weapon.Hit(target);
        }
    }
}
